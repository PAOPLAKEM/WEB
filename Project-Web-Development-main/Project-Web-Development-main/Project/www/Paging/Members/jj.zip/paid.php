<html>
<style>
        table,th,td{
            border: 1px solid black;
        }
    </style>
<head>
	<link rel="stylesheet" href="../../style.css">
	<script src="https://kit.fontawesome.com/f52401267a.js" crossorigin="anonymous"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script>
        function send() { 

            var po = document.getElementById("ph").value;
            var pa = document.getElementById("po").value;

            document.location="editpage.php?PAID="+pa +"&Phone_cus="+po;
}
    </script>
	<?php 
    	session_start();
    	if (isset($_GET['logout'])) {
        	session_destroy();
        	unset($_SESSION['username']);
        	header('location: frame.php');
    	}
	?>
    <?php 
           include('ser.php');
           $stmt = $pdo->prepare("SELECT * FROM customer WHERE `role` LIKE '%user%'");
           $stmt->execute();?>
</head>

    <body>
    <div class="banner">
		<div class="navbar">
			<img src="logo.jpg" width="150px" height="150px">
			<ul>
				<li><a href="admin.php" id="home" onclick="getPaging(this.id)">UPDATE</a></li>
				<li><a href="#" id="paid" onclick="getPaging(this.id)">PAID</a></li>
			</ul>
		</div>
	</div >
    <div class="content" id="content">
        <form >
          <table> <tr><th>ชื่อ:</th><th>เบอร์:</th><th>PAID</th><th>รูป</th></tr>
            <?php while ($row = $stmt->fetch()) :?>
                <tr>
                <td ><?=$row["name_cus"]?></td>
                <td ><?=$row["Phone_cus"]?></td>
                <td>
                    <input type="hidden" id="ph" value="<?=$row["Phone_cus"]?>">
            <select name="PAID" id="po" onchange="send()" >
            <option value="#"><?=$row["PAID"]?></option>
            <option value="0">0</option>
            <option value="1">1</option>
             </td>
            
                </tr>
                <?php endwhile?>     
    </form>   
            
		
	</div>
         
    </body>
</html>