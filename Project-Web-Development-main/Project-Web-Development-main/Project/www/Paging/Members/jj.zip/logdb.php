<?php 
    session_start();
    include('ser.php');

        $username = mysqli_real_escape_string($conn, $_POST['Username']);
        $password = mysqli_real_escape_string($conn, $_POST['Password']);

        
            $password1 = md5($password);
            $ry = "SELECT * FROM customer WHERE Username = '$username' AND `Password` = '$password' ";
            $result = mysqli_query($conn, $ry);

            if (mysqli_num_rows($result) == 1 ) {

                $row= mysqli_fetch_array($result);

                if($row['role'] =='user'){
                $_SESSION['username'] = $username;
                $_SESSION['success'] = "Your are now logged in";
                header("location:../../frame.php ");
                }if($row['role'] =='admin'){
                $_SESSION['username'] = $username;
                $_SESSION['success'] = "Your are now logged in";
                header("location: admin.php");}
            }
            else {
                header("location: log.php");
            }
?>