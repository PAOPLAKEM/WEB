<!DOCTYPE html>
<html>
    <title>
        web page
    </title>
 <link rel="stylesheet" href="web.css">
    <body class="background-image">
        <div class="center">
            <h1>Login</h1>
            <form method="post" action="logdb.php">
              <div class="field">
                Username
                <input type="text" required name="Username">
                <span></span>
                
              </div>
              <div class="field">
                Password
                <input type="password" required name="Password">
                <span></span>
              </div>
              <input type="submit" value="Login" name="log">
              <div class="signup" >
                Not a member? <a href="regis.php">Signup</a>
              </div>
            </form>
          </div>
    </body>
</html>