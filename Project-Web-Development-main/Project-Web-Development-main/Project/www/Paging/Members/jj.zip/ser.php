<?php 
$pdo = new PDO("mysql:host=localhost;dbname=webfarm;charset=utf8", "root", "");
           $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "webfarm";

    $conn = mysqli_connect($servername, $username, $password, $dbname);
?>