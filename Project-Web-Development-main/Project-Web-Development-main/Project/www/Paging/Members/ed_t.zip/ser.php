<?php 
$pdo = new PDO("mysql:host=localhost;dbname=shrimp;charset=utf8", "root", "");
           $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "shrimp";

    $conn = mysqli_connect($servername, $username, $password, $dbname);
?>